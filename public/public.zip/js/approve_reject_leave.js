//this function is used to call confirmation
function changeLeaveStatus(leave_status_change_path,title,text,token,type,id, status)
{
    swal({
        title: title,
        type: type,
        showCancelButton: true,
        confirmButtonText: "Yes, change it!",
        cancelButtonText: "No, cancel it!",
        closeOnConfirm: true,
        closeOnCancel: true
    }, function(isConfirm) {
        if (isConfirm) {
            deleteRequest(leave_status_change_path,id,token, status);
        } 
    });
}
//this function  is used to check coming data is array or not
function checkLength(delete_id)
{
    var selected_length = delete_id.size();

    if(0 == selected_length){
        EmptyData();
    }else{
        var id = [];
        $.each(delete_id, function(i, ele){
            id.push($(ele).val());
        });
        deleteRecord(leave_status_change_path,title,text,token,type,id, status)
    }
}
//this function  is used to call delete record
function deleteRequest(leave_status_change_path,id,token, status)
{
    $.ajax({
        url: leave_status_change_path,
        type:'post',
        dataType:'json',
        data:{id:id,_token: token, status:status},
        beforeSend:function(){
            $(".overlay").show();
            $('#spin').show();
        },
        complete:function(){
            $('#spin').hide();
            $(".overlay").hide();
            var redrawtable = $('#dataTable').dataTable();
            redrawtable.fnStandingRedraw();
        }
    });
}
//Give Error when no data is selected
function EmptyData()
{
    swal({
       title: "Please Select a Record to delete/block",
       type:"error",
       timer: 2000,
       showConfirmButton: false 
    });
}